# Output images

These images show the output from running each Python program with its built-in sample data. They are rendered from the captured console output in a terminal-style layout, not screenshots from a student's computer. The corresponding text output is provided alongside each image.
